﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Folha_Tunada
{
    public partial class Form1 : Form
    {
        Class1 v = new Class1();
        public Form1()
        {
            InitializeComponent();
        }
        string SoEsses = "0123456789.";

        
        private void txtid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(SoEsses.Contains(e.KeyChar.ToString().ToUpper())))
            {
                e.Handled = true;
            }
        }

        private void txtSalario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(SoEsses.Contains(e.KeyChar.ToString().ToUpper())))
            {
                e.Handled = true; 
            }
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            lblID.Text = txtid.Text;
            if (txtid.Text == "" || txtid.Text == null)
            {
                MessageBox.Show("preencha o campo ID corretamente!", "atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (txtSalario.Text == "" || txtSalario.Text == null)
            {
                MessageBox.Show("preencha o campo Salario corretamente!", "atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (txtOnibus.Text == "" || txtOnibus.Text == null)
            {
                MessageBox.Show("preencha o campo Onibus corretamente!", "atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (txtAtrasos.Text == "" || txtAtrasos.Text == null)
            {
                MessageBox.Show("preencha o campo Horas Extras corretamente!", "atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (txtFretado.Text == "" || txtFretado.Text == null)
            {
                MessageBox.Show("preencha o campo Onibus Fretado corretamente!", "atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (txtFaltas.Text == "" || txtFaltas.Text == null)
            {
                MessageBox.Show("preencha o campo Faltas corretamente!", "atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (txtDependentes.Text == "" || txtDependentes.Text == null)
            {
                MessageBox.Show("preencha o campo Dependentes corretamente!", "atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (txtHorasExtras.Text == "" || txtHorasExtras.Text == null)
            {
                MessageBox.Show("preencha o campo Atrasos corretamente!", "atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //salario bruto
            lblBruto.Text = txtSalario.Text;

            double bruto = Convert.ToDouble(txtSalario.Text);
            double a = bruto / 220;
            double b = a * 50 / 100;
            double c = a + b;
            double he = c * 12;
            //dsr
            double dsr=0;
            if (txtHorasExtras.Text != null || txtHorasExtras.Text != "")
            {
                  
            }
            //salario familia
            if (txtDependentes.Text != null || txtDependentes.Text != "")
            {
                double familia;
                if(bruto <= 859.88)
                {
                    familia = 44.09 * Convert.ToDouble(txtDependentes);
                    lblFamilia.Text = Convert.ToString(familia);
                }
                else if (bruto >859.88 && bruto <= 1292.43)
                {
                    familia = 31.07 * Convert.ToDouble(txtDependentes);
                    lblFamilia.Text = Convert.ToString(familia);
                }
            }
            //vale transporte
            if (txtOnibus.Text != null || txtOnibus.Text != "")
            {
                double onibus = bruto * 6 / 100;
            }
            //onibus fretado
            if (txtFretado.Text != null || txtFretado.Text != "")
            {
                double fretado = bruto * 6 / 100;
                lblFretado.Text = Convert.ToString(fretado);
            }
            //inss
            double soma, inss,fgts,irrf;
            soma = bruto + he + dsr;
            if (txtHorasExtras.Text != null || txtHorasExtras.Text != "")
            {
                if (bruto <= 1659.38)
                {
                    inss = soma * 8 / 100;
                }
                else if (bruto > 1659.38 && bruto <= 2765.66)
                {
                    inss = soma * 9 / 100;
                }
                else
                {
                    inss = soma * 11 / 100;
                }
            }
            else
            {
                if (bruto <= 1659.38)
                {
                    inss = soma * 8 / 100;
                }
                else if (bruto > 1659.38 && bruto <= 2765.66)
                {
                    inss = soma * 9 / 100;
                }
                else
                {
                    inss = soma * 11 / 100;
                }
            }
            //fgts
            if (txtHorasExtras.Text != null || txtHorasExtras.Text != "")
            {
                fgts = soma * 8 / 100;
            }
            else
            {
                fgts = bruto * 8 / 100;
            }
            //irrf
            if (bruto > 1903.38 && bruto <= 2826.65)
            {
                irrf = 142.80;
            }
            else if (bruto > 2826.65 && bruto <= 3751.05)
            {
                irrf = 345.80;
            }
            else if (bruto > 3751.05 && bruto <= 4664.68)
            {
                irrf = 636.13;
            }
            else
            {
                irrf = 869.36;
            }
            //faltas
            if (txtFaltas.Text != null || txtFaltas.Text != "")
            {
                double faltas = bruto / 30 *Convert.ToDouble(txtFaltas.Text);
                lblFaltas.Text = Convert.ToString(faltas);
            }
            //atrasos
            if (txtAtrasos.Text != null || txtAtrasos.Text != "")
            {
                double atraso = a * Convert.ToDouble(txtAtrasos.Text);
                lblAtrasos.Text = Convert.ToString(atraso);
            }
        }

        private void txtHorasExtra_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(SoEsses.Contains(e.KeyChar.ToString().ToUpper())))
            {
                e.Handled = true;
            }
        }

        private void txtAtrasos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(SoEsses.Contains(e.KeyChar.ToString().ToUpper())))
            {
                e.Handled = true;
            }
        }

        private void txtFaltas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(SoEsses.Contains(e.KeyChar.ToString().ToUpper())))
            {
                e.Handled = true;
            }
        }

        private void txtOnibus_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(SoEsses.Contains(e.KeyChar.ToString().ToUpper())))
            {
                e.Handled = true;
            }
        }

        private void txtFretado_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(SoEsses.Contains(e.KeyChar.ToString().ToUpper())))
            {
                e.Handled = true;
            }
        }

        private void txtDependentes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(SoEsses.Contains(e.KeyChar.ToString().ToUpper())))
            {
                e.Handled = true;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            txtid.Clear();
            txtFretado.Clear();
            txtDependentes.Clear();
            txtAtrasos.Clear();
            txtFaltas.Clear();
            txtHorasExtras.Clear();
            txtOnibus.Clear();
            txtSalario.Clear();
        }

        
    }
}
