﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejfvsdjfsdfgdghngj_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double salario, onibus, hora, atraso, dsr, dependentes, salariohora, horaextra, salariosoma, inss, valorextra, fgts, somairrf, irrf, pagarirrf, onibusconta, familia, salariofinal;

        private void button9_Click(object sender, EventArgs e)
        {
            if (sfdGravarArquivo.ShowDialog() == DialogResult.OK)
            {
                StreamWriter wr = new StreamWriter(sfdGravarArquivo.FileName, true);
                wr.WriteLine("ID Funcionário: " + lblID.Text + " Salario Bruto: " + lblBruto.Text + " DSR: " + lblDSR.Text
                    + " Salario Familia: " + lblFamilia.Text + " Vale Transporte: " + lblTransporte.Text + " INSS: " +
                    lblINSS.Text + " FGTS: " + lblFGTS.Text + " IRRF: " + lblIRRF.Text + " Atrasos: " + lblAtrasos.Text + " Salario Liquido: "
                    + lblLiquido.Text);
                wr.Close();
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            txtAtrasos.Clear();
            txtDependentes.Clear();
            txtFaltas.Clear();
            txtHorasExtras.Clear();
            txtid.Clear();
            txtOnibus.Clear();
            txtSalario.Clear();
           
        }

        private void txtFretado_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) && !(e.KeyChar == (char)Keys.Back))
            {
                e.Handled = true;
            }
        }

        private void txtDependentes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) && !(e.KeyChar == (char)Keys.Back))
            {
                e.Handled = true;
            }
        }

        private void txtOnibus_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) && !(e.KeyChar == (char)Keys.Back))
            {
                e.Handled = true;
            }
        }

        private void txtFaltas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) && !(e.KeyChar == (char)Keys.Back))
            {
                e.Handled = true;
            }
        }

        private void txtAtrasos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) && !(e.KeyChar == (char)Keys.Back))
            {
                e.Handled = true;
            }
        }

        private void txtHorasExtras_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) && !(e.KeyChar == (char)Keys.Back))
            {
                e.Handled = true;
            }
        }

        private void txtSalario_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Cógigo para limitar o uso da virgula
            if (!Char.IsDigit(e.KeyChar) && !(e.KeyChar == (char)Keys.Back) && !(e.KeyChar == ','))
            {
                e.Handled = true;

            }
            if (e.KeyChar == ',' && (sender as TextBox).Text.IndexOf(',') > -1)
            {
                e.Handled = true;
            }
        }

        private void txtid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !(e.KeyChar == (char)Keys.Back))
            {
                e.Handled = true;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (txtAtrasos.Text == "" || txtDependentes.Text == "" || txtFaltas.Text == "" || txtHorasExtras.Text == "" || txtid.Text == "" || txtOnibus.Text == "" || txtSalario.Text == "")
            {
                MessageBox.Show("preencha os dados corretamente !!! atenção as observações !");
            }
            else
            {
                salario = Convert.ToDouble(txtSalario.Text);
                hora = Convert.ToDouble(txtHorasExtras.Text);
                atraso = Convert.ToDouble(txtAtrasos.Text);
                dependentes = Convert.ToDouble(txtDependentes.Text);
                onibus = Convert.ToDouble(txtOnibus.Text);

                salariohora = salario / 220;
                valorextra = salariohora * 1.5;
                horaextra = valorextra * hora;
                dsr = valorextra * 4;
                salariosoma = salario + horaextra + dsr;
                atraso = salariohora * atraso;

                if (salariosoma <= 1659.38)
                {
                    inss = salariosoma * 0.08;
                }
                else if (salariosoma >= 1659.39 && salariosoma <= 2765.66)
                {
                    inss = salariosoma * 0.09;
                }
                else
                {
                    inss = salariosoma * 0.11;
                }

                fgts = salariosoma * 0.08;
                somairrf = salariosoma - inss;

                if (somairrf >= 1903.38 && somairrf <= 2826.65)
                {
                    pagarirrf = (somairrf * 0.075) - 142.80;
                    irrf = 142.80;
                }
                else if (somairrf >= 2826.66 && somairrf <= 3751.05)
                {
                    pagarirrf = (somairrf * 0.15) - 345.80;
                    irrf = 345.80;
                }
                else if (somairrf >= 3751.06 && somairrf <= 4664.68)
                {
                    pagarirrf = (somairrf * 0.225) - 636.13;
                    irrf = 636.13;
                }
                else if (somairrf >= 4664.69)
                {
                    pagarirrf = (somairrf * 0.275) - 869.36;
                    irrf = 869.36;
                }
                else
                {
                    irrf = 0;
                }

                if (onibus >= 1)
                {
                    onibusconta = salario * 0.06;
                }
                else
                {
                    onibusconta = 0;
                }

                if (salario <= 859.88)
                {
                    familia = 44.09 * dependentes;
                }
                else if (salario >= 859.89 && salario <= 1292.43)
                {
                    familia = 31.07 * dependentes;
                }
                else
                {
                    familia = 0;
                }
                salariofinal = salariosoma - inss - fgts - irrf - atraso - onibusconta + familia;

                lblID.Text = txtid.Text;
                lblBruto.Text = Convert.ToString(salario);
                lblDSR.Text = Convert.ToString(dsr);
                lblFamilia.Text = Convert.ToString(familia);
                lblTransporte.Text = Convert.ToString(onibusconta);
                lblINSS.Text = Convert.ToString(inss);
                lblFGTS.Text = Convert.ToString(fgts);
                lblIRRF.Text = Convert.ToString(irrf);
                lblAtrasos.Text = Convert.ToString(atraso);
                lblLiquido.Text = Convert.ToString(salariofinal);
            }
        }
    }
}
